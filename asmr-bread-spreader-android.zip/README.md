# ASMR Bread Spreader — 3D (Web → Android via GitHub Actions)

**Very Simple APK Build (Free):**
1) Create a repo on GitHub.
2) Upload all files from this folder (keep `.github/workflows/android.yml`).
3) GitHub will build the Android APK for you automatically.
4) Download APK from the Actions tab (artifact).

## Local run
```
npm install
npm run dev
```
Open the URL Vite prints.

## Web → APK
- GitHub Action runs:
  - `npm run build`
  - `npx cap init ... && npx cap add android && npx cap copy`
  - Gradle `assembleDebug` to create `app-debug.apk`.
