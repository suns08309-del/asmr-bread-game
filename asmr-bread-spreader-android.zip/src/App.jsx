import React, { useEffect, useMemo, useRef, useState } from "react";
import * as THREE from "three";
import { motion } from "framer-motion";

const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
function breadTextureCanvas(w,h){
  const c=document.createElement('canvas'); c.width=w; c.height=h; const ctx=c.getContext('2d');
  for(let y=0;y<h;y++){ for(let x=0;x<w;x++){ const nx=x/140, ny=y/140; const n1=Math.abs(Math.sin(nx*6+ny*2)), n2=Math.abs(Math.cos(nx*2.5+ny*3)); let crumb=236 + n1*18 + n2*8; let r=crumb, g=crumb-6, b=crumb-16; const dx=(x-w/2)/(w/2), dy=(y-h/2)/(h/2); const v=clamp(1-(dx*dx+dy*dy)*0.28,0.6,1); r*=v; g*=v; b*=v; ctx.fillStyle=`rgb(${r|0},${g|0},${b|0})`; ctx.fillRect(x,y,1,1);} }
  const border=Math.floor(Math.min(w,h)*0.06);
  ctx.globalCompositeOperation='multiply';
  const grad=ctx.createLinearGradient(0,0,0,h); grad.addColorStop(0,'#8b5a2b'); grad.addColorStop(1,'#5a381a');
  ctx.lineWidth=border*2; ctx.strokeStyle=grad; ctx.strokeRect(border,border,w-border*2,h-border*2); ctx.globalCompositeOperation='source-over';
  return c;
}

export default function App(){
  const mountRef=useRef(null);
  const rendererRef=useRef(null);
  const cameraRef=useRef(null);
  const sceneRef=useRef(null);
  const breadRef=useRef(null);
  const texCanvasRef=useRef(null);
  const texRef=useRef(null);
  const pointer=useMemo(()=>new THREE.Vector2(),[]);
  const [brushSize,setBrushSize]=useState(0.08);
  const [pressure,setPressure]=useState(0.7);

  useEffect(()=>{
    const mount=mountRef.current;
    const renderer=new THREE.WebGLRenderer({antialias:true,alpha:false});
    renderer.outputColorSpace=THREE.SRGBColorSpace;
    renderer.setPixelRatio(Math.min(window.devicePixelRatio||1,2));
    renderer.setSize(mount.clientWidth,mount.clientHeight);
    mount.appendChild(renderer.domElement); rendererRef.current=renderer;

    const scene=new THREE.Scene(); scene.background=new THREE.Color(0x0b0b0b); sceneRef.current=scene;
    const camera=new THREE.PerspectiveCamera(45,mount.clientWidth/mount.clientHeight,0.01,100); camera.position.set(0,0.9,1.4); camera.lookAt(0,0,0); cameraRef.current=camera;
    scene.add(new THREE.HemisphereLight(0xffffff,0x443322,0.9));
    const dir=new THREE.DirectionalLight(0xffffff,1.0); dir.position.set(1.2,1.3,0.4); scene.add(dir);

    const board=new THREE.Mesh(new THREE.PlaneGeometry(2.6,1.8), new THREE.MeshStandardMaterial({color:0x5c4028,roughness:0.95}));
    board.rotation.x=-Math.PI/2; board.position.y=-0.05; scene.add(board);

    const breadGeo=new THREE.BoxGeometry(1.7,0.12,1.0,64,4,64);
    const breadBaseTex=new THREE.CanvasTexture(breadTextureCanvas(1024,1024)); breadBaseTex.colorSpace=THREE.SRGBColorSpace;

    texCanvasRef.current=document.createElement('canvas'); texCanvasRef.current.width=1024; texCanvasRef.current.height=1024;
    const spreadTex=new THREE.CanvasTexture(texCanvasRef.current); spreadTex.colorSpace=THREE.SRGBColorSpace; spreadTex.needsUpdate=true; texRef.current=spreadTex;

    const breadMat=new THREE.MeshPhysicalMaterial({ map:breadBaseTex, metalness:0.0, roughness:0.8, clearcoat:0.0, side:THREE.DoubleSide });
    breadMat.onBeforeCompile = (shader)=>{
      shader.uniforms.spreadTex={ value: spreadTex };
      // Ensure UVs are present and use WebGL2 'texture' function
      shader.fragmentShader = shader.fragmentShader
        .replace('#include <map_pars_fragment>', `
          #include <map_pars_fragment>
          uniform sampler2D spreadTex;
        `)
        .replace('#include <map_fragment>', `
          #include <map_fragment>
          vec4 spreadCol = texture(spreadTex, vUv);
          float smear = spreadCol.a;
          diffuseColor.rgb = mix(diffuseColor.rgb, spreadCol.rgb, smear);
        `);
    };

    const bread=new THREE.Mesh(breadGeo,breadMat); bread.position.y=0.03; bread.rotation.y=0.02; scene.add(bread); breadRef.current=bread;

    const onResize=()=>{ const w=mount.clientWidth,h=mount.clientHeight; renderer.setSize(w,h); camera.aspect=w/h; camera.updateProjectionMatrix(); };
    const ro=new ResizeObserver(onResize); ro.observe(mount);

    let raf;
    const loop=()=>{ renderer.render(scene,camera); raf=requestAnimationFrame(loop); };
    raf=requestAnimationFrame(loop);
    return ()=>{ cancelAnimationFrame(raf); ro.disconnect(); mount.removeChild(renderer.domElement); renderer.dispose(); };
  },[]);

  useEffect(()=>{
    const mount=mountRef.current; if(!mount) return;
    const handlePointer=(e)=>{
      const r=mount.getBoundingClientRect();
      const x=(e.clientX-r.left)/r.width; const y=(e.clientY-r.top)/r.height;
      const u=x, v=1-y; stamp(u,v);
    };
    mount.addEventListener('pointerdown',handlePointer);
    mount.addEventListener('pointermove', (e)=>{ if(e.buttons) handlePointer(e); });
    return ()=>{
      mount.removeEventListener('pointerdown',handlePointer);
      mount.removeEventListener('pointermove',handlePointer);
    };
  },[brushSize,pressure]);

  function stamp(u,v){
    const c=texCanvasRef.current; if(!c) return;
    const ctx=c.getContext('2d'); const size=c.width*brushSize;
    const x=u*c.width, y=v*c.height;
    ctx.filter='blur(3px)';
    ctx.fillStyle=`rgba(255,230,120,${0.25+pressure*0.55})`;
    ctx.beginPath(); ctx.ellipse(x,y,size*0.55,size*0.45,0,0,Math.PI*2); ctx.fill();
    ctx.filter='none';
    texRef.current.needsUpdate=true;
  }

  function resetLayer(){
    const c=texCanvasRef.current; if(!c) return;
    const ctx=c.getContext('2d'); ctx.clearRect(0,0,c.width,c.height);
    texRef.current.needsUpdate=true;
  }

  function export4K(){
    const r=rendererRef.current; if(!r) return;
    const prev=r.getSize(new THREE.Vector2()); const dpr=r.getPixelRatio();
    r.setPixelRatio(1); r.setSize(3840,2160,false);
    r.render(sceneRef.current,cameraRef.current);
    const url=r.domElement.toDataURL('image/png');
    const a=document.createElement('a'); a.href=url; a.download='asmr-bread-4k.png'; a.click();
    r.setSize(prev.x,prev.y,false); r.setPixelRatio(dpr);
  }

  return (<div className="w-full h-[100vh]" style={{background:'#0b0b0b',color:'#fff',display:'grid',gridTemplateColumns:'1fr 320px',gap:'12px'}}>
    <div ref={mountRef} style={{borderRadius:'16px',overflow:'hidden',background:'#111',minHeight:'60vh'}}/>
    <div style={{background:'#111',borderRadius:'16px',padding:'12px'}}>
      <h2 style={{margin:'0 0 12px 0'}}>ASMR Bread Spreader — 3D</h2>
      <label>Brush Size
        <input type="range" min="0.02" max="0.25" step="0.005" value={brushSize} onChange={(e)=>setBrushSize(parseFloat(e.target.value))}/>
      </label>
      <label>Pressure
        <input type="range" min="0" max="1" step="0.01" value={pressure} onChange={(e)=>setPressure(parseFloat(e.target.value))}/>
      </label>
      <div style={{display:'flex',gap:'8px',marginTop:'8px'}}>
        <button onClick={resetLayer}>Reset</button>
        <button onClick={export4K}>Export 4K PNG</button>
      </div>
    </div>
  </div>);
}
